import React, { Component } from 'react';
import { View, Text, Button} from 'react-native';



export default class HomeView extends Component{




	render(){
		return(
			<View style={{flex:1}}>
				<Text>Texto en HomeView</Text>
				<Button
				title={'Login'}
				onPress={()=>this.props.navigation.navigate('Login')}
				/>
			</View>
		)
	}

}